from sys import argv
import re
import time

from PyQt5.QtCore import QObject, QTimer, pyqtProperty, pyqtSignal
from PyQt5.QtGui import QGuiApplication
from PyQt5.QtQml import QQmlListProperty, QQmlApplicationEngine, qmlRegisterType

from PyQt5 import QtCore

#!/usr/bin/env python3

import socket
import threading

HOST = '127.0.0.1'  # The server's hostname or IP address
PORT = 2468  # The default port used by the server

class Receiver(QObject):

    msg_number=0
    dataChanged = QtCore.pyqtSignal(str)

    def handle_race_data(self):
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
            s.connect((HOST, PORT))
            s.sendall(b'start')

            while True:
                self.msg_number+=1
                s.sendall(bytes(str(self.msg_number),'utf-8')) #you need to send at least 1 byte to get next message
                data = s.recv(1024)

                x=data.decode('utf-8')
                print("type of data: {}".format(x))

                self.dataChanged.emit(x) #add to emit data

                if (data==b'None'):
                    print('.......No more data is coming. Exiting.')
                    input('Press enter to exit') #add to see console log
                    #exit(0)

                print(data.decode('utf-8'))

class BeatRecord(QObject):

    numberChanged = pyqtSignal()
    nameChanged = pyqtSignal()

    def __init__(self, number='', name='', *args, **kwargs):
        super().__init__(*args, **kwargs)
        self._number = number
        self._name = name

    @pyqtProperty('QString', notify=numberChanged)
    def number(self):
        return self._number

    @pyqtProperty('QString', notify=nameChanged)
    def name(self):
        return self._name

    @number.setter
    def number(self, number):
        if number != self._number:
            self._number = number
            self.numberChanged.emit()

    @name.setter
    def name(self, name):
        if name != self._name:
            self._name = name
            self.nameChanged.emit()

    def getNum(self):
        return self._number

    def getName(self):
        return self._name

class MoreThan32(QObject):

    numberMChanged = pyqtSignal()
    nameMChanged = pyqtSignal()

    def __init__(self, numberM='', nameM='', *args, **kwargs):
        super().__init__(*args, **kwargs)
        self._numberM = numberM
        self._nameM = nameM

    @pyqtProperty('QString', notify=numberMChanged)
    def numberM(self):
        return self._numberM

    @pyqtProperty('QString', notify=nameMChanged)
    def nameM(self):
        return self._nameM

    @numberM.setter
    def numberM(self, numberM):
        if numberM != self._numberM:
            self._numberM = numberM
            self.numberMChanged.emit()

    @nameM.setter
    def nameM(self, nameM):
        if nameM != self._nameM:
            self._nameM = nameM
            self.nameMChanged.emit()

    def getNumM(self):
        return self._numberM

    def getNameM(self):
        return self._nameM


class Predict(BeatRecord):

    numberPChanged = pyqtSignal()
    namePChanged = pyqtSignal()
    contentPChanged = pyqtSignal()

    def __init__(self, numberP='', nameP='', contentP='', *args, **kwargs):
        super().__init__(*args, **kwargs)
        self._numberP = numberP
        self._nameP = nameP
        self._contentP = contentP

    @pyqtProperty('QString', notify=numberPChanged)
    def numberP(self):
        return self._numberP

    @pyqtProperty('QString', notify=namePChanged)
    def nameP(self):
        return self._nameP

    @numberP.setter
    def numberP(self, numberP):
        if numberP != self._numberP:
            self._numberP = numberP
            self.numberPChanged.emit()

    @nameP.setter
    def nameP(self, nameP):
        if nameP != self._nameP:
            self._nameP = nameP
            self.namePChanged.emit()

    def getNumP(self):
        return self._numberP

    def getNameP(self):
        return self._nameP

    @pyqtProperty('QString', notify=contentPChanged)
    def contentP(self):
        return self._contentP

    @contentP.setter
    def contentP(self, contentP):
        if contentP != self._contentP:
            self._contentP = contentP
            self.contentPChanged.emit()

    def getContentP(self):
        return self._contentP

class FinalScore(Predict):

    rankChanged = pyqtSignal()
    numberChanged = pyqtSignal()
    nameChanged = pyqtSignal()
    contentChanged = pyqtSignal()

    def __init__(self, rank='', number='', name='', content='', *args, **kwargs):
        super().__init__(*args, **kwargs)
        self._rank = rank
        self._number = number
        self._name = name
        self._content = content

    @pyqtProperty('QString', notify=numberChanged)
    def number(self):
        return self._number

    @pyqtProperty('QString', notify=nameChanged)
    def name(self):
        return self._name

    @number.setter
    def number(self, number):
        if number != self._number:
            self._number = number
            self.numberChanged.emit()

    @name.setter
    def name(self, name):
        if name != self._name:
            self._name = name
            self.nameChanged.emit()

    def getNum(self):
        return self._number

    def getName(self):
        return self._name

    @pyqtProperty('QString', notify=contentChanged)
    def content(self):
        return self._content

    @content.setter
    def content(self, content):
        if content != self._content:
            self._content = content
            self.contentChanged.emit()

    def getContent(self):
        return self._content

    @pyqtProperty('QString', notify=rankChanged)
    def rank(self):
        return self._rank

    @rank.setter
    def rank(self, rank):
        if rank != self._rank:
            self._rank = rank
            self.rankChanged.emit()

    def getRank(self):
        return self._rank

class DataManager(QObject):

    beatRecordsChanged = pyqtSignal()
    moreThan32sChanged = pyqtSignal()
    predictChanged = pyqtSignal()
    finalScoreChanged = pyqtSignal()

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self._beatRecords = [
            BeatRecord('No.   Name', ''),
        ]
        self._moreThan32s = [
            MoreThan32('No.   Name', ''),
        ]
        self._predict = [
            Predict('No.   Name', '', 'Predict contents'),
        ]
        self._finalScore = [
            FinalScore(' ', 'No.', 'Name', 'Final score'),
        ]

    #================================================================
    #handle beat record
    #================================================================
    @pyqtProperty(QQmlListProperty, notify=beatRecordsChanged)
    def beatRecords(self):
        return QQmlListProperty(BeatRecord, self, self._beatRecords)

    @beatRecords.setter
    def beatRecords(self, beatRecords):
        if beatRecords != self._beatRecords:
            self._beatRecords = beatRecords
            self.beatRecordsChanged.emit()

    def appendBeatRecords(self, beatRecords):
        self._beatRecords.append(beatRecords)
        self.beatRecordsChanged.emit()

    def deleteBeatRecords(self, num):
        print("delete beatRecord entered--{}----------------------------->".format(num))
        for v in self._beatRecords:
            if v.getNum() == num:
                self._beatRecords.remove(v)
                return

    def addBeatRecords(self, num, beatRecord):
        for v in self._beatRecords:
            if v.getNum() == num:
                return
        self.appendBeatRecords(beatRecord)

    def pBeatRecords(self):
        return self._beatRecords

    #================================================================
    #handle more than 32
    #================================================================
    @pyqtProperty(QQmlListProperty, notify=moreThan32sChanged)
    def moreThan32s(self):
        return QQmlListProperty(MoreThan32, self, self._moreThan32s)

    @moreThan32s.setter
    def moreThan32s(self, moreThan32s):
        if moreThan32s != self._moreThan32s:
            self._moreThan32s = moreThan32s
            self.moreThan32sChanged.emit()

    def appendMoreThan32s(self, moreThan32s):
        self._moreThan32s.append(moreThan32s)
        self.moreThan32sChanged.emit()

    def deleteMoreThan32s(self, num):
        print("delete MoreThan32 entered------------------------------->")
        for v in self._moreThan32s:
            if v.getNumM() == num:
                self._moreThan32s.remove(v)
                self.moreThan32sChanged.emit()
                return

    def addMoreThan32s(self, num, moreThan32s):
        for v in self._moreThan32s:
            if v.getNumM() == num:
                return
        self.appendMoreThan32s(moreThan32s)

    def pMoreThan32s(self):
        return self._moreThan32s

    #================================================================
    #handle predict record
    #================================================================
    @pyqtProperty(QQmlListProperty, notify=predictChanged)
    def predict(self):
        return QQmlListProperty(Predict, self, self._predict)

    @predict.setter
    def predict(self, predict):
        if predict != self._predict:
            self._predict = predict
            self.predictChanged.emit()

    def appendPredict(self, predict):
        self._predict.append(predict)
        self.predictChanged.emit()

    def deletePredict(self, num):
        print("delete Predict entered------------------------------->")
        for v in self._predict:
            if v.getNumP() == num:
                print('delete Predict num is: {}'.format(v.getNumP()))
                self._predict.remove(v)
                self.predictChanged.emit()
                return       

    def pPredict(self):
        return self._predict

    #================================================================
    #handle final score
    #================================================================
    @pyqtProperty(QQmlListProperty, notify=finalScoreChanged)
    def finalScore(self):
        return QQmlListProperty(FinalScore, self, self._finalScore)

    @finalScore.setter
    def finalScore(self, finalScore):
        if finalScore != self._finalScore:
            self._finalScore = finalScore
            self.finalScoreChanged.emit()

    def appendFinalScore(self, finalScore):
        self._finalScore.append(finalScore)
        self.finalScoreChanged.emit()

    def pFinalScore(self):
        return self._finalScore

class Processing:
    def __init__(self, dataManager):
        self.dataManager = dataManager

        self.averageTime = [1.48,3.38,5.39,7.43,9.17,10.85,12.18,13.23,14.02,14.62, \
                       15.14,15.64,16.19,16.84,17.63,18.49,19.33,20.17,20.82,21.18]
        self.record = [0.74,1.41,1.68,2.57,4.43,5.28,6.24,6.76,7.48,7.55, \
                  7.82,8.21,8.61,9.24,9.56,10.4,11.1,12.0,12.23,12.56]
        self.rank = 1

        nameList = []
        self.nameDict = {}
        try:
            file1 = open('names.txt', 'r')
            while True:
                lines = file1.readline()
                if not lines:
                    break
                else:
                    if lines != "":
                        data = lines.split()
                        print(data)
                        nameList.append(data)
            file1.close()
        except:
            print('Read names.txt error.')
            pass
        try:
            self.nameDict = {nameList[i][0]: nameList[i][1] for i in range(0, len(nameList))}
        except:
            print('nameList to dict has error')
            pass
        print(self.nameDict)

    def didthing(self,inputStr):
        print("enter didthing!!@!@!@!@!@!@")
        print("inputStr: {}".format(inputStr))
        x = inputStr
        x = x[1:-1]
        t = re.split(', ',x)
        print(t)
        if len(t) == 3:
            a,b,c = t
            elapsedTime,num,gate = float(a),b,int(c)
            if gate > 0 and gate <= 20:
                timeSlots=[]

                #update gate record
                if self.record[gate - 1] > elapsedTime:
                    self.dataManager.addBeatRecords(num, BeatRecord(num, self.nameDict[num]))
                else:
                    self.dataManager.deleteBeatRecords(num)

                if gate < 20: #when receive gate 20, no need to predict
                    #update predict time
                    gap=self.record[gate]-elapsedTime
                    timeSlots=self.averageTime[gate:]
                    timeSlots=[x - gap for x in timeSlots]
                    s = []
                    d = gate + 1
                    for i in timeSlots:
                        s += str(d) + ':' + str(str(round(i,2))) + ' '
                        d += 1
                    j = ''
                    j = j.join(s)
                    self.dataManager.deletePredict(num)
                    self.dataManager.appendPredict(Predict(num, self.nameDict[num], j))

                    #update more than 32 hour
                    if timeSlots[-1] > 32:
                        self.dataManager.addMoreThan32s(num, MoreThan32(num, self.nameDict[num]))
                    else:
                        self.dataManager.deleteMoreThan32s(num)

                else: #gate==20
                    self.dataManager.deletePredict(num)

                    if elapsedTime < 32:
                        self.dataManager.deleteMoreThan32s(num)
                    else:
                        self.dataManager.addMoreThan32s(num, MoreThan32(num, self.nameDict[num]))

                    self.dataManager.appendFinalScore(FinalScore(str(self.rank), num, self.nameDict[num], str(round(elapsedTime,2))))
                    self.rank += 1

def main():

    app = QGuiApplication(argv)

    qmlRegisterType(BeatRecord, 'Example', 1, 0, 'BeatRecord')
    qmlRegisterType(MoreThan32, 'Example', 1, 0, 'MoreThan32')
    qmlRegisterType(Predict, 'Example', 1, 0, 'Predict')
    qmlRegisterType(FinalScore, 'Example', 1, 0, 'FinalScore')
    qmlRegisterType(DataManager, 'Example', 1, 0, 'DataManager')

    dataManager = DataManager()
    processing = Processing(dataManager)

    engine = QQmlApplicationEngine()
    engine.rootContext().setContextProperty('dataManager', dataManager)
    engine.load('main.qml')

    myreceiver = Receiver()
    myreceiver.dataChanged.connect(lambda val: processing.didthing(val))
    listeningThread = threading.Thread(target=myreceiver.handle_race_data)

    input('Press enter to start')
    listeningThread.start()

    exit(app.exec_())

if __name__ == '__main__':
    main()
